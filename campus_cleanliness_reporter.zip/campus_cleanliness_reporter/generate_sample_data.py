"""Regenerates data/sample_reports.csv and data/sample_reports.json (deterministic)."""
import csv
import json
import random
from datetime import date, timedelta
from pathlib import Path

random.seed(42)
OUT = Path(__file__).parent / "data"
END = date(2026, 11, 18)

# (location, category, mean rating tendency, typical issues, typical notes)
PLACES = [
    ("Main Cafeteria", "Cafeteria", 1.8, ["Spill", "Overflowing Bin", "Pest"], ["Tables sticky after lunch rush", "Bins overflowing by 2pm", "Flies near the counter"]),
    ("Hostel Block A - Restroom", "Restroom", 1.6, ["Bad Odor", "Broken Fixture"], ["Strong smell, floor wet", "Tap leaking again", "No soap in dispenser"]),
    ("Central Library - Ground Floor", "Library", 4.2, ["None", "Litter"], ["Quiet and tidy", "A few wrappers under desks"]),
    ("Engineering Block - Lab 2", "Laboratory", 3.6, ["None", "Spill"], ["Benches wiped", "Coolant spill near bench 4"]),
    ("Sports Complex Pavilion", "Sports Area", 2.9, ["Litter", "Graffiti"], ["Bottles left after match", "New graffiti on back wall"]),
    ("Admin Block Corridor", "Corridor", 4.5, ["None"], ["Spotless", "Cleaned this morning"]),
    ("Lecture Hall 101", "Classroom", 3.4, ["Litter", "None"], ["Whiteboard not erased", "Chalk dust on floor"]),
    ("North Gate Garden", "Outdoor", 2.7, ["Litter", "Overflowing Bin"], ["Leaves and plastic cups", "Bin full since weekend"]),
]
REPORTERS = ["Aarav", "Diya", "Rohan", "Meera", "Kabir", "Ishita", "Anonymous"]

rows = []
for i in range(38):
    name, cat, mean, issues, notes = random.choice(PLACES + PLACES[:3])   # bias towards problem areas
    rating = max(1, min(5, round(random.gauss(mean, 0.8))))
    issue = "None" if rating >= 5 else random.choice(issues)
    day = END - timedelta(days=random.randint(0, 27))
    rows.append({"date": day.isoformat(), "location": name, "category": cat, "rating": rating,
                 "issue_type": issue, "notes": random.choice(notes), "reporter": random.choice(REPORTERS)})

# deliberate boundary / edge cases (all valid)
rows += [
    {"date": END.isoformat(), "location": "Hostel Block A - Restroom", "category": "Restroom", "rating": 1,
     "issue_type": "Bad Odor", "notes": "Blocked drain - boundary rating 1", "reporter": "Warden"},
    {"date": (END - timedelta(days=1)).isoformat(), "location": "Admin Block Corridor", "category": "Corridor",
     "rating": 5, "issue_type": "None", "notes": "", "reporter": "Anonymous"},                       # empty notes, rating 5
    {"date": (END - timedelta(days=2)).isoformat(), "location": "AB", "category": "Outdoor", "rating": 3,
     "issue_type": "None", "notes": "x" * 200, "reporter": "Edge Case"},                              # 2-char location, 200-char note
]
rows.sort(key=lambda r: r["date"])

fields = ["date", "location", "category", "rating", "issue_type", "notes", "reporter"]
with (OUT / "sample_reports.csv").open("w", newline="", encoding="utf-8") as fh:
    w = csv.DictWriter(fh, fieldnames=fields); w.writeheader(); w.writerows(rows)

with (OUT / "sample_reports.json").open("w", encoding="utf-8") as fh:
    json.dump({"schema_version": 1,
               "reports": [{"id": i, **r} for i, r in enumerate(rows, 1)]}, fh, indent=2)

# a deliberately messy file to demo the importer's row-by-row error log
bad = [
    "date,location,category,rating,issue_type,notes,reporter",
    "2026-11-10,Lecture Hall 101,Classroom,4,None,Looks fine,Aarav",
    "2026-13-45,Lecture Hall 101,Classroom,3,None,bad date,Aarav",
    "2026-11-11,Main Cafeteria,Cafeteria,9,Spill,rating out of range,Diya",
    "2026-11-11,Main Cafeteria,Cafeteria,abc,Spill,non-numeric rating,Diya",
    "2026-11-12,,Library,3,None,blank location,Rohan",
    "2026-11-12,Central Library - Ground Floor,Gym,3,None,unknown category,Rohan",
    "2099-01-01,Sports Complex Pavilion,Sports Area,2,Litter,future date,Meera",
    "2026-11-13,Sports Complex Pavilion,Sports Area,2,Litter,valid row,Meera",
    "2026-11-13,Sports Complex Pavilion,Sports Area,2,Litter,valid row,Meera",
]
(OUT / "legacy_import_with_errors.csv").write_text("\n".join(bad) + "\n", encoding="utf-8")
print(f"Wrote {len(rows)} sample rows.")
