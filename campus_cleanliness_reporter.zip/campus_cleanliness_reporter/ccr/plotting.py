"""Matplotlib charts. Degrades gracefully if matplotlib is not installed."""
from datetime import datetime
from pathlib import Path

from .analytics import daily_averages, location_stats
from .models import status_for

COLORS = {"Critical": "#d9534f", "Needs Attention": "#f0ad4e", "Good": "#5cb85c"}


def available() -> bool:
    try:
        import matplotlib  # noqa: F401
        return True
    except ImportError:
        return False


def generate_charts(reports, out_dir) -> list[Path]:
    """Create four PNG charts and return their paths. Raises ImportError if matplotlib is missing."""
    import matplotlib
    matplotlib.use("Agg")                      # headless-safe backend
    import matplotlib.pyplot as plt

    out_dir = Path(out_dir); out_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    paths = []

    # 1. Average rating by location (lowest 10)
    stats = location_stats(reports)[:10][::-1]
    fig, ax = plt.subplots(figsize=(9, 5))
    ax.barh([s["location"] for s in stats], [s["avg_rating"] for s in stats],
            color=[COLORS[status_for(round(s["avg_rating"]))] for s in stats])
    ax.set_xlim(0, 5); ax.set_xlabel("Average rating (1 = filthy, 5 = spotless)")
    ax.set_title("Lowest-rated locations")
    fig.tight_layout(); p = out_dir / f"chart_locations_{stamp}.png"; fig.savefig(p, dpi=120); plt.close(fig); paths.append(p)

    # 2. Rating distribution
    counts = [sum(1 for r in reports if r.rating == n) for n in range(1, 6)]
    fig, ax = plt.subplots(figsize=(7, 4.5))
    ax.bar(range(1, 6), counts, color=[COLORS[status_for(n)] for n in range(1, 6)])
    ax.set_xlabel("Rating"); ax.set_ylabel("Number of reports"); ax.set_title("Rating distribution")
    fig.tight_layout(); p = out_dir / f"chart_distribution_{stamp}.png"; fig.savefig(p, dpi=120); plt.close(fig); paths.append(p)

    # 3. Daily trend with 7-day rolling mean
    daily = daily_averages(reports)
    if daily:
        days = [datetime.fromisoformat(d) for d, _ in daily]
        vals = [v for _, v in daily]
        roll = [sum(vals[max(0, i - 6):i + 1]) / len(vals[max(0, i - 6):i + 1]) for i in range(len(vals))]
        fig, ax = plt.subplots(figsize=(9, 4.5))
        ax.plot(days, vals, marker="o", alpha=0.5, label="Daily average")
        ax.plot(days, roll, linewidth=2.5, label="7-day rolling mean")
        ax.set_ylim(0.5, 5.5); ax.set_ylabel("Average rating"); ax.set_title("Cleanliness trend")
        ax.legend(); fig.autofmt_xdate(); fig.tight_layout()
        p = out_dir / f"chart_trend_{stamp}.png"; fig.savefig(p, dpi=120); plt.close(fig); paths.append(p)

    # 4. Issue types
    issues = {}
    for r in reports:
        if r.issue_type != "None":
            issues[r.issue_type] = issues.get(r.issue_type, 0) + 1
    if issues:
        items = sorted(issues.items(), key=lambda kv: kv[1])
        fig, ax = plt.subplots(figsize=(7, 4.5))
        ax.barh([k for k, _ in items], [v for _, v in items], color="#5b8def")
        ax.set_xlabel("Reports"); ax.set_title("Most common issue types")
        fig.tight_layout(); p = out_dir / f"chart_issues_{stamp}.png"; fig.savefig(p, dpi=120); plt.close(fig); paths.append(p)
    return paths
