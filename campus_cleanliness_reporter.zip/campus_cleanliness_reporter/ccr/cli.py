"""Menu-driven terminal interface."""
import argparse
from datetime import date
from pathlib import Path

from . import __version__, analytics, export, plotting, ui
from .importer import import_csv
from .storage import Storage
from .validation import (CATEGORIES, ISSUE_TYPES, ValidationError, validate_date, validate_location,
                         validate_notes, validate_rating, validate_reporter)

ROOT = Path(__file__).resolve().parent.parent
DATA_FILE = ROOT / "data" / "reports.json"
SAMPLE_CSV = ROOT / "data" / "sample_reports.csv"
EXPORT_DIR = ROOT / "exports"

HEADERS = ["ID", "Date", "Location", "Category", "Rtg", "Issue", "Status"]
WIDTHS = [4, 10, 28, 12, 3, 15, 15]


def report_rows(reports):
    return [[r.id, r.date, r.location, r.category, r.rating, r.issue_type, r.status] for r in reports]


# ---------------------------------------------------------------- actions
def add_report(app):
    ui.heading("Record a new cleanliness report")
    known = sorted({r.location for r in app.reports})
    if known:
        print(ui.dim("  Known locations: " + ", ".join(known[:8]) + (" ..." if len(known) > 8 else "")))
    print(ui.dim("  Rating scale: 1 = filthy, 2 = poor, 3 = acceptable, 4 = clean, 5 = spotless"))
    raw = {
        "date": ui.ask("Date (YYYY-MM-DD)", validate_date, default=date.today().isoformat()),
        "location": ui.ask("Location", validate_location),
        "category": ui.ask_choice("Category", CATEGORIES),
        "rating": ui.ask("Rating 1-5", validate_rating),
        "issue_type": ui.ask_choice("Issue type", ISSUE_TYPES, default="None"),
        "notes": ui.ask("Notes", validate_notes, allow_blank=True),
        "reporter": ui.ask("Your name", validate_reporter, allow_blank=True),
    }
    report = app.storage.add(raw)
    ui.info(f"Saved report #{report.id} at {report.location} - status: "
            f"{ui.STATUS_COLOR[report.status](report.status)}")
    for w in analytics.warnings([r for r in app.reports if r.location == report.location]):
        ui.warn(w)


def view_reports(app):
    ui.heading("All reports (newest first)")
    rows = report_rows(sorted(app.reports, key=lambda r: (r.date, r.id), reverse=True))
    ui.paginate(HEADERS, rows, WIDTHS, status_col=6)


def search_reports(app):
    ui.heading("Search & filter")
    print(ui.dim("  Leave a filter blank to skip it."))
    kw = ui.ask("Keyword (location, notes, issue...)", lambda v: v.strip(), allow_blank=True)
    cat = ui.ask_choice("Category filter", CATEGORIES, allow_blank=True)
    lo = ui.ask("Minimum rating", lambda v: validate_rating(v) if v else None, allow_blank=True)
    hi = ui.ask("Maximum rating", lambda v: validate_rating(v) if v else None, allow_blank=True)
    results = analytics.filter_reports(app.reports, keyword=kw or None, category=cat or None,
                                       min_rating=lo, max_rating=hi)
    print()
    ui.paginate(HEADERS, report_rows(sorted(results, key=lambda r: r.date, reverse=True)), WIDTHS, status_col=6)


def show_summary(app):
    ui.heading("Executive summary")
    s = analytics.summarize(app.reports)
    if not s["total"]:
        ui.warn("No reports yet - add one or load the sample data.")
        return
    print(f"  Total reports : {ui.bold(s['total'])}   Locations: {ui.bold(s['locations'])}   "
          f"Average rating: {ui.bold(s['avg_rating'])}/5")
    print(f"  Date range    : {s['date_range'][0]} -> {s['date_range'][1]}")
    t = s["trend"]
    arrow = {"improving": ui.green("▲ improving"), "declining": ui.red("▼ declining"),
             "stable": ui.yellow("► stable")}.get(t["direction"], t["direction"])
    print(f"  Weekly trend  : {arrow}  (last 7d {t['recent']} vs previous 7d {t['previous']})")
    print("\n  Status:   " + "   ".join(ui.STATUS_COLOR[k](f"{k}: {v}") for k, v in s["status_counts"].items()))
    print("\n  Rating distribution")
    peak = max(s["rating_distribution"].values()) or 1
    for n, count in s["rating_distribution"].items():
        print(f"    {n} | {'█' * round(20 * count / peak):<20} {count}")
    print("\n  Average rating by category")
    ui.table(["Category", "Avg", "Reports"], [[c, a, n] for c, a, n in s["by_category"]], [14, 5, 8])
    print("\n  Top issues: " + (", ".join(f"{i} ({n})" for i, n in s["top_issues"]) or "none"))
    print("  Worst locations: " + "; ".join(f"{x['location']} ({x['avg_rating']})" for x in s["worst_locations"]))
    print("  Best locations : " + "; ".join(f"{x['location']} ({x['avg_rating']})" for x in s["best_locations"]))
    flags = analytics.warnings(app.reports)
    if flags:
        print()
        for w in flags:
            ui.warn(w)


def show_recurring(app):
    ui.heading("Recurring problem areas")
    rec = analytics.recurring_areas(app.reports)
    if not rec:
        ui.info("No location has repeated low ratings. Nice!")
        return
    print(ui.dim(f"  Locations with {analytics.RECURRING_MIN_LOW}+ reports rated "
                 f"{analytics.LOW_RATING} or lower.\n"))
    rows = [[s["location"], s["reports"], s["low_reports"], s["avg_rating"], s["top_issue"], s["last_reported"]]
            for s in rec]
    ui.paginate(["Location", "Rpts", "Low", "Avg", "Main issue", "Last"], rows, [28, 4, 3, 4, 15, 10])


def make_charts(app):
    ui.heading("Generate charts")
    if not app.reports:
        ui.warn("No data to plot.")
        return
    if not plotting.available():
        ui.error("matplotlib is not installed. Run:  pip install matplotlib")
        ui.warn("Text summaries and exports still work without it.")
        return
    for p in plotting.generate_charts(app.reports, EXPORT_DIR / "charts"):
        ui.info(f"Saved {p.relative_to(ROOT)}")


def export_menu(app):
    ui.heading("Export reports")
    if not app.reports:
        ui.warn("Nothing to export yet.")
        return
    for p in export.export_all(app.reports, EXPORT_DIR):
        ui.info(f"Saved {p.relative_to(ROOT)}")


def import_menu(app):
    ui.heading("Bulk import from CSV")
    print(ui.dim("  Required columns: date, location, category, rating. Optional: issue_type, notes, reporter."))
    path = ui.ask("Path to CSV file", lambda v: v.strip().strip('"'), default=str(ROOT / "data" / "legacy_import_with_errors.csv"))
    res = import_csv(path, app.storage, EXPORT_DIR / "logs")
    if res.fatal:
        ui.error(res.fatal)
        return
    ui.info(f"Imported {res.imported} row(s).")
    if res.skipped_invalid or res.skipped_duplicate:
        ui.warn(f"Skipped {res.skipped_invalid} invalid and {res.skipped_duplicate} duplicate row(s).")
        for n, msg in res.errors[:5]:
            print(f"      row {n}: {msg}")
        if len(res.errors) > 5:
            print(f"      ... and {len(res.errors) - 5} more")
        print(ui.dim(f"  Full error log: {res.log_path.relative_to(ROOT)}"))


def delete_report(app):
    ui.heading("Delete a report")
    rid = ui.ask("Report ID", lambda v: int(v) if v.isdigit() else (_ for _ in ()).throw(
        ValidationError("Enter a numeric report ID.")))
    match = next((r for r in app.reports if r.id == rid), None)
    if not match:
        ui.error(f"No report with ID {rid}.")
    elif ui.confirm(f"Delete #{rid} ({match.location}, {match.date})?"):
        app.storage.delete(rid)
        ui.info("Deleted.")


def load_sample(app):
    ui.heading("Load sample data")
    res = import_csv(SAMPLE_CSV, app.storage, EXPORT_DIR / "logs", rebase_to_today=True)
    if res.fatal:
        ui.error(res.fatal)
    else:
        ui.info(f"Imported {res.imported} sample report(s); {res.skipped_duplicate} duplicate(s) skipped.")


# ---------------------------------------------------------------- app
class App:
    def __init__(self, data_file):
        self.storage = Storage(data_file)

    @property
    def reports(self):
        return self.storage.reports


MENU = [
    ("1", "Record a new report", add_report),
    ("2", "View all reports", view_reports),
    ("3", "Search & filter", search_reports),
    ("4", "Executive summary", show_summary),
    ("5", "Recurring problem areas", show_recurring),
    ("6", "Generate charts (PNG)", make_charts),
    ("7", "Export summary (MD / TXT / CSV)", export_menu),
    ("8", "Bulk import from CSV", import_menu),
    ("9", "Load sample data", load_sample),
    ("d", "Delete a report", delete_report),
    ("0", "Exit", None),
]


def main(argv=None):
    parser = argparse.ArgumentParser(description="Campus Cleanliness Reporter")
    parser.add_argument("--data", default=str(DATA_FILE), help="path to the JSON data file")
    args = parser.parse_args(argv)

    app = App(args.data)
    app.storage.load()
    ui.banner(__version__)
    for note in app.storage.notes:
        ui.warn(note)
    try:
        if not app.reports and SAMPLE_CSV.exists() and ui.confirm("No data yet. Load the sample dataset?", True):
            load_sample(app)
        flags = analytics.warnings(app.reports)
        if flags:
            print()
            for w in flags[:3]:
                ui.warn(w)
        actions = {key: fn for key, _, fn in MENU}
        while True:
            print("\n" + ui.bold("  MAIN MENU"))
            for key, label, _ in MENU:
                print(f"   {ui.cyan(key)}  {label}")
            choice = ui._read("\n  Choose an option: ").strip().lower()
            if choice == "0":
                break
            if choice not in actions:
                ui.error("Please choose one of the listed options.")
                continue
            try:
                actions[choice](app)
            except ValidationError as exc:
                ui.error(f"Invalid data: {exc}")
            except OSError as exc:
                ui.error(f"File problem: {exc.__class__.__name__}: {exc}")
    except KeyboardInterrupt:
        print()
    print(ui.green("\n  Data saved. Keep the campus clean - goodbye!\n"))
    return 0
