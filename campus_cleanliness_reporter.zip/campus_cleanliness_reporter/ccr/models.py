"""Data model for a cleanliness report."""
from dataclasses import dataclass, asdict

from .validation import ValidationError, validate_record

CRITICAL_MAX = 2      # rating <= 2  -> Critical
ATTENTION_MAX = 3     # rating == 3  -> Needs Attention, >= 4 -> Good


def status_for(rating: int) -> str:
    if rating <= CRITICAL_MAX:
        return "Critical"
    if rating <= ATTENTION_MAX:
        return "Needs Attention"
    return "Good"


@dataclass
class Report:
    id: int
    date: str
    location: str
    category: str
    rating: int
    issue_type: str = "None"
    notes: str = ""
    reporter: str = "Anonymous"

    @property
    def status(self) -> str:
        return status_for(self.rating)

    def to_dict(self) -> dict:
        return asdict(self)

    @classmethod
    def from_dict(cls, raw: dict) -> "Report":
        try:
            rid = int(raw["id"])
        except (KeyError, TypeError, ValueError):
            raise ValidationError("Record has a missing or invalid id.") from None
        if rid < 1:
            raise ValidationError("Record id must be positive.")
        return cls(id=rid, **validate_record(raw))
