"""Multi-format exports: Markdown summary, plain-text audit log, CSV reports."""
import csv
from datetime import datetime
from pathlib import Path

from .analytics import location_stats, summarize, warnings
from .models import Report

CSV_FIELDS = ["id", "date", "location", "category", "rating", "issue_type", "notes", "reporter"]


def _stamp() -> str:
    return datetime.now().strftime("%Y%m%d_%H%M%S")


def export_reports_csv(reports: list[Report], out_dir) -> Path:
    out_dir = Path(out_dir); out_dir.mkdir(parents=True, exist_ok=True)
    path = out_dir / f"reports_{_stamp()}.csv"
    with path.open("w", newline="", encoding="utf-8") as fh:
        writer = csv.DictWriter(fh, fieldnames=CSV_FIELDS)
        writer.writeheader()
        for r in reports:
            writer.writerow({k: getattr(r, k) for k in CSV_FIELDS})
    return path


def export_location_csv(reports: list[Report], out_dir) -> Path:
    out_dir = Path(out_dir); out_dir.mkdir(parents=True, exist_ok=True)
    path = out_dir / f"location_summary_{_stamp()}.csv"
    stats = location_stats(reports)
    fields = ["location", "category", "reports", "low_reports", "avg_rating", "top_issue", "last_reported", "status"]
    with path.open("w", newline="", encoding="utf-8") as fh:
        writer = csv.DictWriter(fh, fieldnames=fields)
        writer.writeheader()
        writer.writerows(stats)
    return path


def export_markdown(reports: list[Report], out_dir) -> Path:
    out_dir = Path(out_dir); out_dir.mkdir(parents=True, exist_ok=True)
    s = summarize(reports)
    path = out_dir / f"summary_{_stamp()}.md"
    L = ["# Campus Cleanliness Report", "", f"_Generated {datetime.now():%Y-%m-%d %H:%M}_", ""]
    if not s["total"]:
        L.append("No reports recorded yet.")
    else:
        L += ["## Overview", "",
              f"- **Total reports:** {s['total']}",
              f"- **Locations covered:** {s['locations']}",
              f"- **Average rating:** {s['avg_rating']} / 5",
              f"- **Date range:** {s['date_range'][0]} to {s['date_range'][1]}",
              f"- **Trend (last 7 days vs previous 7):** {s['trend']['direction']}", "",
              "## Status breakdown", "", "| Status | Count |", "|---|---|"]
        L += [f"| {k} | {v} |" for k, v in s["status_counts"].items()]
        L += ["", "## Recurring problem areas", ""]
        if s["recurring"]:
            L += ["| Location | Low reports | Avg | Main issue | Last reported |", "|---|---|---|---|---|"]
            L += [f"| {r['location']} | {r['low_reports']} | {r['avg_rating']} | {r['top_issue']} | {r['last_reported']} |"
                  for r in s["recurring"]]
        else:
            L.append("No recurring problem areas detected.")
        L += ["", "## Average rating by category", "", "| Category | Avg | Reports |", "|---|---|---|"]
        L += [f"| {c} | {a} | {n} |" for c, a, n in s["by_category"]]
        L += ["", "## Top issues", ""] + [f"- {i}: {n}" for i, n in s["top_issues"]]
        w = warnings(reports)
        L += ["", "## Warnings", ""] + ([f"- {x}" for x in w] if w else ["- None"])
    path.write_text("\n".join(L) + "\n", encoding="utf-8")
    return path


def export_audit_log(reports: list[Report], out_dir) -> Path:
    out_dir = Path(out_dir); out_dir.mkdir(parents=True, exist_ok=True)
    path = out_dir / f"audit_log_{_stamp()}.txt"
    L = [f"CAMPUS CLEANLINESS REPORTER - AUDIT LOG ({datetime.now():%Y-%m-%d %H:%M:%S})",
         "=" * 78, f"Total records: {len(reports)}", ""]
    for r in sorted(reports, key=lambda r: (r.date, r.id)):
        L.append(f"#{r.id:04d} {r.date} | {r.location} [{r.category}] | rating {r.rating} ({r.status}) | "
                 f"issue: {r.issue_type} | by {r.reporter}" + (f" | note: {r.notes}" if r.notes else ""))
    L += ["", "WARNINGS", "-" * 78] + (warnings(reports) or ["None"])
    path.write_text("\n".join(L) + "\n", encoding="utf-8")
    return path


def export_all(reports, out_dir) -> list[Path]:
    return [export_markdown(reports, out_dir), export_audit_log(reports, out_dir),
            export_reports_csv(reports, out_dir), export_location_csv(reports, out_dir)]
