"""Bulk CSV import with row-by-row validation and an error log."""
import csv
from datetime import date, timedelta
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path

from .validation import ValidationError, validate_record

REQUIRED_COLUMNS = {"date", "location", "category", "rating"}


@dataclass
class ImportResult:
    imported: int = 0
    skipped_invalid: int = 0
    skipped_duplicate: int = 0
    errors: list = field(default_factory=list)     # (row_number, message)
    fatal: str = ""
    log_path: Path | None = None


def _rebase_delta(rows):
    dates = []
    for r in rows:
        try:
            dates.append(date.fromisoformat((r.get("date") or "").strip()))
        except ValueError:
            pass
    return (date.today() - max(dates)) if dates else None


def import_csv(path, storage, log_dir, rebase_to_today: bool = False) -> ImportResult:
    """Import a CSV. With rebase_to_today, dates are shifted so the newest row is today (for demo data)."""
    result = ImportResult()
    path = Path(path)
    try:
        handle = path.open("r", newline="", encoding="utf-8-sig")
    except (FileNotFoundError, IsADirectoryError, PermissionError, OSError) as exc:
        result.fatal = f"Cannot open file: {exc.__class__.__name__}"
        return result
    with handle:
        try:
            reader = csv.DictReader(handle)
            header = {(h or "").strip().lower() for h in (reader.fieldnames or [])}
            missing = REQUIRED_COLUMNS - header
            if missing:
                result.fatal = f"CSV is missing required column(s): {', '.join(sorted(missing))}"
                return result
            rows = [{(k or "").strip().lower(): v for k, v in r.items() if k is not None} for r in reader]
            delta = _rebase_delta(rows) if rebase_to_today else None
            for row_no, row in enumerate(rows, start=2):     # row 1 is the header
                if delta is not None:
                    try:
                        row["date"] = (date.fromisoformat(row["date"].strip()) + delta).isoformat()
                    except (ValueError, KeyError, AttributeError):
                        pass                                  # leave it for validation to report
                try:
                    clean = validate_record(row)
                except ValidationError as exc:
                    result.skipped_invalid += 1
                    result.errors.append((row_no, str(exc)))
                    continue
                if storage.is_duplicate(clean):
                    result.skipped_duplicate += 1
                    result.errors.append((row_no, "Duplicate of an existing report (skipped)."))
                    continue
                storage.add(clean, save=False)
                result.imported += 1
        except (csv.Error, UnicodeDecodeError) as exc:
            result.fatal = f"File could not be parsed as CSV ({exc.__class__.__name__})."
    if result.imported:
        storage.save()
    if result.errors:
        log_dir = Path(log_dir)
        log_dir.mkdir(parents=True, exist_ok=True)
        result.log_path = log_dir / f"import_errors_{datetime.now():%Y%m%d_%H%M%S}.log"
        lines = [f"Import log for {path.name}", f"Imported: {result.imported}",
                 f"Invalid rows: {result.skipped_invalid}", f"Duplicates: {result.skipped_duplicate}", ""]
        lines += [f"Row {n}: {msg}" for n, msg in result.errors]
        result.log_path.write_text("\n".join(lines) + "\n", encoding="utf-8")
    return result
