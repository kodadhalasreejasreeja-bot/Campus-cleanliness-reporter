"""JSON persistence with corruption recovery and atomic writes."""
import json
import os
from datetime import datetime
from pathlib import Path

from .models import Report
from .validation import ValidationError, validate_record

SCHEMA_VERSION = 1


class Storage:
    def __init__(self, path):
        self.path = Path(path)
        self.reports: list[Report] = []
        self.notes: list[str] = []      # human-readable messages from load()

    # ---------- loading ----------
    def load(self) -> None:
        self.notes = []
        self.reports = []
        try:
            text = self.path.read_text(encoding="utf-8")
        except FileNotFoundError:
            self.notes.append("No data file found - created a fresh one.")
            self.save()
            return
        except (OSError, UnicodeDecodeError) as exc:
            self._quarantine(f"unreadable ({exc.__class__.__name__})")
            return
        try:
            data = json.loads(text)
        except json.JSONDecodeError:
            self._quarantine("invalid JSON")
            return
        if not isinstance(data, dict) or not isinstance(data.get("reports"), list):
            self._quarantine("unexpected structure")
            return
        skipped = 0
        for item in data["reports"]:
            try:
                self.reports.append(Report.from_dict(item))
            except (ValidationError, TypeError, KeyError, ValueError):
                skipped += 1
        if skipped:
            self.notes.append(f"Skipped {skipped} invalid stored record(s) while loading.")

    def _quarantine(self, reason: str) -> None:
        stamp = datetime.now().strftime("%Y%m%d-%H%M%S")
        backup = self.path.with_name(f"{self.path.stem}.corrupt-{stamp}{self.path.suffix}")
        try:
            os.replace(self.path, backup)
            self.notes.append(f"Data file was {reason}. Backed up to {backup.name} and started fresh.")
        except OSError:
            self.notes.append(f"Data file was {reason}. Started fresh.")
        self.save()

    # ---------- saving ----------
    def save(self) -> None:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        payload = {"schema_version": SCHEMA_VERSION,
                   "reports": [r.to_dict() for r in self.reports]}
        tmp = self.path.with_name(self.path.name + ".tmp")
        tmp.write_text(json.dumps(payload, indent=2), encoding="utf-8")
        os.replace(tmp, self.path)

    # ---------- mutations ----------
    def next_id(self) -> int:
        return max((r.id for r in self.reports), default=0) + 1

    def add(self, raw: dict, save: bool = True) -> Report:
        clean = validate_record(raw)
        report = Report(id=self.next_id(), **clean)
        self.reports.append(report)
        if save:
            self.save()
        return report

    def delete(self, report_id: int) -> bool:
        before = len(self.reports)
        self.reports = [r for r in self.reports if r.id != report_id]
        if len(self.reports) != before:
            self.save()
            return True
        return False

    def is_duplicate(self, clean: dict) -> bool:
        key = (clean["date"], clean["location"].lower(), clean["rating"],
               clean["reporter"].lower(), clean["notes"].lower())
        return any((r.date, r.location.lower(), r.rating, r.reporter.lower(), r.notes.lower()) == key
                   for r in self.reports)
