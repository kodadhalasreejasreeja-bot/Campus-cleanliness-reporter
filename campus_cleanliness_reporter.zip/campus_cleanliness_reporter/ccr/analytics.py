"""Filtering, summary statistics, recurring-area detection and threshold warnings."""
from collections import Counter, defaultdict
from datetime import date, timedelta
from statistics import mean

from .models import Report, status_for

LOW_RATING = 2            # a "low" report is rating <= 2
RECURRING_MIN_LOW = 2     # a location is "recurring" with >= 2 low reports
HOTSPOT_WINDOW_DAYS = 14
HOTSPOT_MIN_LOW = 3       # >= 3 low reports within the window -> hotspot warning


def filter_reports(reports, keyword=None, category=None, location=None,
                   min_rating=None, max_rating=None, date_from=None, date_to=None,
                   issue_type=None):
    out = []
    kw = keyword.lower() if keyword else None
    for r in reports:
        if kw and kw not in f"{r.location} {r.notes} {r.issue_type} {r.category} {r.reporter}".lower():
            continue
        if category and r.category != category:
            continue
        if issue_type and r.issue_type != issue_type:
            continue
        if location and location.lower() not in r.location.lower():
            continue
        if min_rating is not None and r.rating < min_rating:
            continue
        if max_rating is not None and r.rating > max_rating:
            continue
        if date_from and r.date < date_from:
            continue
        if date_to and r.date > date_to:
            continue
        out.append(r)
    return out


def location_stats(reports: list[Report]) -> list[dict]:
    groups = defaultdict(list)
    for r in reports:
        groups[r.location].append(r)
    stats = []
    for loc, items in groups.items():
        issues = Counter(i.issue_type for i in items if i.issue_type != "None")
        avg = mean(i.rating for i in items)
        stats.append({
            "location": loc,
            "category": Counter(i.category for i in items).most_common(1)[0][0],
            "reports": len(items),
            "low_reports": sum(1 for i in items if i.rating <= LOW_RATING),
            "avg_rating": round(avg, 2),
            "top_issue": issues.most_common(1)[0][0] if issues else "None",
            "last_reported": max(i.date for i in items),
            "status": status_for(round(avg)),
        })
    return sorted(stats, key=lambda s: (s["avg_rating"], -s["reports"]))


def recurring_areas(reports: list[Report], min_low: int = RECURRING_MIN_LOW) -> list[dict]:
    """Locations that were reported as dirty (rating <= 2) at least `min_low` times."""
    rec = [s for s in location_stats(reports) if s["low_reports"] >= min_low]
    return sorted(rec, key=lambda s: (-s["low_reports"], s["avg_rating"]))


def weekly_trend(reports: list[Report]) -> dict:
    """Compare the average rating of the latest 7 days of data with the 7 days before."""
    if not reports:
        return {"direction": "n/a", "recent": None, "previous": None}
    latest = max(date.fromisoformat(r.date) for r in reports)
    cut1, cut2 = latest - timedelta(days=7), latest - timedelta(days=14)
    recent = [r.rating for r in reports if date.fromisoformat(r.date) > cut1]
    prev = [r.rating for r in reports if cut2 < date.fromisoformat(r.date) <= cut1]
    if not recent or not prev:
        return {"direction": "not enough data", "recent": mean(recent) if recent else None,
                "previous": mean(prev) if prev else None}
    diff = mean(recent) - mean(prev)
    direction = "improving" if diff > 0.15 else "declining" if diff < -0.15 else "stable"
    return {"direction": direction, "recent": round(mean(recent), 2), "previous": round(mean(prev), 2)}


def daily_averages(reports: list[Report]) -> list[tuple[str, float]]:
    by_day = defaultdict(list)
    for r in reports:
        by_day[r.date].append(r.rating)
    return [(d, round(mean(v), 2)) for d, v in sorted(by_day.items())]


def summarize(reports: list[Report]) -> dict:
    if not reports:
        return {"total": 0}
    ratings = [r.rating for r in reports]
    cat = defaultdict(list)
    for r in reports:
        cat[r.category].append(r.rating)
    issues = Counter(r.issue_type for r in reports if r.issue_type != "None")
    return {
        "total": len(reports),
        "locations": len({r.location for r in reports}),
        "avg_rating": round(mean(ratings), 2),
        "rating_distribution": {n: ratings.count(n) for n in range(1, 6)},
        "status_counts": dict(Counter(r.status for r in reports)),
        "by_category": sorted(((c, round(mean(v), 2), len(v)) for c, v in cat.items()), key=lambda x: x[1]),
        "top_issues": issues.most_common(5),
        "worst_locations": location_stats(reports)[:3],
        "best_locations": sorted(location_stats(reports), key=lambda s: -s["avg_rating"])[:3],
        "recurring": recurring_areas(reports),
        "trend": weekly_trend(reports),
        "date_range": (min(r.date for r in reports), max(r.date for r in reports)),
    }


def warnings(reports: list[Report], as_of: date | None = None) -> list[str]:
    """Console warning flags: hotspots, recurring areas and critical recent reports."""
    if not reports:
        return []
    as_of = as_of or max(date.fromisoformat(r.date) for r in reports)
    start = (as_of - timedelta(days=HOTSPOT_WINDOW_DAYS)).isoformat()
    recent_low = Counter(r.location for r in reports if r.date > start and r.rating <= LOW_RATING)
    out = [f"HOTSPOT: '{loc}' has {n} low-rated reports in the last {HOTSPOT_WINDOW_DAYS} days."
           for loc, n in recent_low.most_common() if n >= HOTSPOT_MIN_LOW]
    out += [f"RECURRING: '{s['location']}' has {s['low_reports']} low-rated reports overall "
            f"(avg {s['avg_rating']}, main issue: {s['top_issue']})."
            for s in recurring_areas(reports) if recent_low.get(s["location"], 0) < HOTSPOT_MIN_LOW]
    crit_today = [r for r in reports if r.date == as_of.isoformat() and r.rating == 1]
    out += [f"CRITICAL: rating 1 reported at '{r.location}' on {r.date}." for r in crit_today]
    return out
