"""Campus Cleanliness Reporter - record cleanliness reports and find recurring problem areas."""
__version__ = "1.0.0"
