"""Centralised, defensive validation used by the CLI, the storage layer and the CSV importer."""
import re
from datetime import date, datetime, timedelta

CATEGORIES = ["Classroom", "Restroom", "Cafeteria", "Library", "Hostel",
              "Corridor", "Laboratory", "Outdoor", "Sports Area"]
ISSUE_TYPES = ["None", "Litter", "Overflowing Bin", "Spill", "Bad Odor",
               "Broken Fixture", "Graffiti", "Pest"]
MIN_RATING, MAX_RATING = 1, 5
MAX_NOTES, MAX_LOCATION, MAX_REPORTER = 200, 60, 40
LOCATION_RE = re.compile(r"^[A-Za-z0-9 .,&'()/\-]+$")
_CTRL_RE = re.compile(r"[\x00-\x1f\x7f]")


class ValidationError(ValueError):
    """Raised when a value violates a domain constraint."""


def clean_text(value) -> str:
    """Strip control characters and collapse whitespace."""
    if value is None:
        return ""
    return " ".join(_CTRL_RE.sub(" ", str(value)).split())


def validate_date(value, today: date | None = None) -> str:
    today = today or date.today()
    text = clean_text(value)
    try:
        parsed = datetime.strptime(text, "%Y-%m-%d").date()
    except ValueError:
        raise ValidationError("Date must be a real date in YYYY-MM-DD format.") from None
    if parsed > today:
        raise ValidationError("Date cannot be in the future.")
    if parsed < today - timedelta(days=5 * 365):
        raise ValidationError("Date is more than 5 years old - please check it.")
    return parsed.isoformat()


def validate_location(value) -> str:
    text = clean_text(value)
    if len(text) < 2:
        raise ValidationError("Location must be at least 2 characters.")
    if len(text) > MAX_LOCATION:
        raise ValidationError(f"Location must be at most {MAX_LOCATION} characters.")
    if not LOCATION_RE.match(text):
        raise ValidationError("Location may only contain letters, digits, spaces and . , & ' ( ) / -")
    return text


def validate_rating(value) -> int:
    if isinstance(value, bool):
        raise ValidationError("Rating must be a whole number.")
    try:
        number = float(str(value).strip())
    except ValueError:
        raise ValidationError("Rating must be a number.") from None
    if number != number or number in (float("inf"), float("-inf")) or number != int(number):
        raise ValidationError("Rating must be a whole number.")
    number = int(number)
    if not MIN_RATING <= number <= MAX_RATING:
        raise ValidationError(f"Rating must be between {MIN_RATING} and {MAX_RATING}.")
    return number


def validate_choice(value, options: list[str], label: str = "Option") -> str:
    """Accept a canonical name (case-insensitive) or a 1-based index."""
    text = clean_text(value)
    if text.isdigit() and 1 <= int(text) <= len(options):
        return options[int(text) - 1]
    for option in options:
        if option.lower() == text.lower():
            return option
    raise ValidationError(f"{label} must be one of: {', '.join(options)}.")


def validate_notes(value) -> str:
    text = clean_text(value)
    if len(text) > MAX_NOTES:
        raise ValidationError(f"Notes must be at most {MAX_NOTES} characters (got {len(text)}).")
    return text


def validate_reporter(value) -> str:
    text = clean_text(value) or "Anonymous"
    if len(text) > MAX_REPORTER:
        raise ValidationError(f"Reporter name must be at most {MAX_REPORTER} characters.")
    return text


def validate_record(raw: dict, today: date | None = None) -> dict:
    """Validate a raw mapping (CSV row / JSON object) and return clean field values."""
    if not isinstance(raw, dict):
        raise ValidationError("Record must be an object.")
    missing = [k for k in ("date", "location", "category", "rating") if clean_text(raw.get(k)) == ""]
    if missing:
        raise ValidationError(f"Missing required field(s): {', '.join(missing)}.")
    return {
        "date": validate_date(raw.get("date"), today),
        "location": validate_location(raw.get("location")),
        "category": validate_choice(raw.get("category"), CATEGORIES, "Category"),
        "rating": validate_rating(raw.get("rating")),
        "issue_type": validate_choice(raw.get("issue_type") or "None", ISSUE_TYPES, "Issue type"),
        "notes": validate_notes(raw.get("notes")),
        "reporter": validate_reporter(raw.get("reporter")),
    }
