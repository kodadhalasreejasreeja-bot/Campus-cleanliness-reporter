"""Terminal helpers: ANSI colours, tables, pagination and validated prompt loops."""
import os
import sys

from .validation import ValidationError

_USE_COLOR = sys.stdout.isatty() and not os.environ.get("NO_COLOR")
if os.name == "nt":
    os.system("")          # enable ANSI escapes on Windows 10+ terminals


def c(text, code):
    return f"\033[{code}m{text}\033[0m" if _USE_COLOR else str(text)


def bold(t): return c(t, "1")
def red(t): return c(t, "91")
def green(t): return c(t, "92")
def yellow(t): return c(t, "93")
def cyan(t): return c(t, "96")
def dim(t): return c(t, "2")


STATUS_COLOR = {"Critical": red, "Needs Attention": yellow, "Good": green}

BANNER = r"""
   ____                                  ____ _
  / ___|__ _ _ __ ___  _ __  _   _ ___  / ___| | ___  __ _ _ __
 | |   / _` | '_ ` _ \| '_ \| | | / __|| |   | |/ _ \/ _` | '_ \
 | |__| (_| | | | | | | |_) | |_| \__ \| |___| |  __/ (_| | | | |
  \____\__,_|_| |_| |_| .__/ \__,_|___/ \____|_|\___|\__,_|_| |_|
                      |_|        Cleanliness Reporter
"""


def banner(version):
    print(cyan(BANNER))
    print(dim(f"  StudentLife Hack  |  Environment & Sustainability  |  v{version}\n"))


def heading(text):
    print("\n" + bold(cyan(f"== {text} ")) + cyan("=" * max(3, 70 - len(text))))


def info(t): print(green("  ✔ ") + t)
def warn(t): print(yellow("  ⚠ ") + t)
def error(t): print(red("  ✖ ") + t)


def trunc(text, width):
    text = str(text)
    return text if len(text) <= width else text[:width - 1] + "…"


def table(headers, rows, widths, status_col=None):
    """Fixed-width table. `status_col` is the index of a column to colourise by status."""
    line = "+" + "+".join("-" * (w + 2) for w in widths) + "+"
    print(line)
    print("| " + " | ".join(bold(trunc(h, w).ljust(w)) for h, w in zip(headers, widths)) + " |")
    print(line)
    for row in rows:
        cells = []
        for i, (val, w) in enumerate(zip(row, widths)):
            cell = trunc(val, w).ljust(w)
            if i == status_col:
                cell = STATUS_COLOR.get(str(val), str)(cell)
            cells.append(cell)
        print("| " + " | ".join(cells) + " |")
    print(line)


def paginate(headers, rows, widths, page_size=10, status_col=None):
    if not rows:
        print(dim("  (no records)"))
        return
    pages = (len(rows) + page_size - 1) // page_size
    for p in range(pages):
        table(headers, rows[p * page_size:(p + 1) * page_size], widths, status_col)
        print(dim(f"  Page {p + 1}/{pages} - {len(rows)} record(s)"))
        if p < pages - 1:
            if input("  [Enter] next page, [q] stop: ").strip().lower() == "q":
                break


def _read(prompt):
    try:
        return input(prompt)
    except EOFError:
        print()
        raise KeyboardInterrupt from None


def ask(prompt, validator, default=None, allow_blank=False, hint=None):
    """Loop until `validator(text)` returns a value. Enter accepts `default`."""
    suffix = f" [{default}]" if default not in (None, "") else (" (optional)" if allow_blank else "")
    while True:
        raw = _read(f"  {prompt}{suffix}: ").strip()
        if raw == "":
            if default is not None:
                raw = str(default)
            elif allow_blank:
                return validator("") if validator else ""
        try:
            return validator(raw)
        except ValidationError as exc:
            error(str(exc) + (f" {hint}" if hint else ""))


def ask_choice(prompt, options, default=None, allow_blank=False):
    from .validation import validate_choice
    for i, opt in enumerate(options, 1):
        print(f"    {i}. {opt}")
    def validator(v):
        if v == "" and allow_blank:
            return ""
        return validate_choice(v, options, prompt)
    return ask(prompt + " (number or name)", validator, default=default, allow_blank=allow_blank)


def confirm(prompt, default=False):
    raw = _read(f"  {prompt} [{'Y/n' if default else 'y/N'}]: ").strip().lower()
    return default if raw == "" else raw in ("y", "yes")
