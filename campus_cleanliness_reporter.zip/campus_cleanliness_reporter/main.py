#!/usr/bin/env python3
"""Entry point:  python main.py"""
import sys

if sys.version_info < (3, 10):
    sys.exit("Campus Cleanliness Reporter needs Python 3.10 or newer.")

from ccr.cli import main

if __name__ == "__main__":
    sys.exit(main())
