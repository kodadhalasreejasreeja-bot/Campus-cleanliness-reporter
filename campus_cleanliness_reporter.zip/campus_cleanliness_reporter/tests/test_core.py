import csv
import json
import tempfile
import unittest
from datetime import date, timedelta
from pathlib import Path

from ccr import analytics, export
from ccr.importer import import_csv
from ccr.storage import Storage
from ccr.validation import (ValidationError, validate_choice, validate_date, validate_location,
                            validate_notes, validate_rating, validate_record)

ROOT = Path(__file__).resolve().parent.parent


def raw(**kw):
    base = {"date": date.today().isoformat(), "location": "Lab 1", "category": "Laboratory",
            "rating": 3, "issue_type": "None", "notes": "", "reporter": "T"}
    base.update(kw)
    return base


class ValidationTests(unittest.TestCase):
    def test_rating_bounds_and_types(self):
        self.assertEqual(validate_rating("1"), 1)
        self.assertEqual(validate_rating(" 5 "), 5)
        self.assertEqual(validate_rating("4.0"), 4)
        for bad in ["0", "6", "-1", "abc", "", "3.5", "nan", "inf", True]:
            with self.assertRaises(ValidationError, msg=repr(bad)):
                validate_rating(bad)

    def test_dates(self):
        today = date(2026, 11, 21)
        self.assertEqual(validate_date("2026-11-21", today), "2026-11-21")
        for bad in ["2026-11-22", "2026-02-30", "21/11/2026", "", "2015-01-01"]:
            with self.assertRaises(ValidationError, msg=bad):
                validate_date(bad, today)

    def test_location_and_notes(self):
        self.assertEqual(validate_location("  Hostel   A  "), "Hostel A")
        for bad in ["", "A", "x" * 61, "<script>"]:
            with self.assertRaises(ValidationError):
                validate_location(bad)
        self.assertEqual(len(validate_notes("x" * 200)), 200)
        with self.assertRaises(ValidationError):
            validate_notes("x" * 201)

    def test_choice_by_name_or_number(self):
        self.assertEqual(validate_choice("library", ["Classroom", "Library"]), "Library")
        self.assertEqual(validate_choice("2", ["Classroom", "Library"]), "Library")
        with self.assertRaises(ValidationError):
            validate_choice("3", ["Classroom", "Library"])

    def test_record_requires_fields(self):
        with self.assertRaises(ValidationError):
            validate_record({"date": "2026-01-01"})


class StorageTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.path = Path(self.tmp.name) / "reports.json"

    def tearDown(self):
        self.tmp.cleanup()

    def test_missing_file_created(self):
        s = Storage(self.path); s.load()
        self.assertTrue(self.path.exists())
        self.assertEqual(s.reports, [])

    def test_roundtrip_persistence(self):
        s = Storage(self.path); s.load(); s.add(raw()); s.add(raw(location="Hall 2"))
        s2 = Storage(self.path); s2.load()
        self.assertEqual([r.id for r in s2.reports], [1, 2])
        self.assertEqual(s2.next_id(), 3)

    def test_corrupt_json_recovered(self):
        self.path.write_text("{not json", encoding="utf-8")
        s = Storage(self.path); s.load()
        self.assertEqual(s.reports, [])
        self.assertTrue(any("Backed up" in n for n in s.notes))
        self.assertTrue(list(Path(self.tmp.name).glob("reports.corrupt-*.json")))

    def test_wrong_structure_recovered(self):
        self.path.write_text("[1,2,3]", encoding="utf-8")
        s = Storage(self.path); s.load()
        self.assertEqual(s.reports, [])

    def test_invalid_records_skipped(self):
        good = {"id": 1, **raw()}
        bad = {"id": 2, **raw(rating=99)}
        self.path.write_text(json.dumps({"reports": [good, bad]}), encoding="utf-8")
        s = Storage(self.path); s.load()
        self.assertEqual(len(s.reports), 1)
        self.assertTrue(any("Skipped 1" in n for n in s.notes))

    def test_rejects_invalid_add(self):
        s = Storage(self.path); s.load()
        with self.assertRaises(ValidationError):
            s.add(raw(rating=0))
        self.assertEqual(s.reports, [])


class AnalyticsTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.s = Storage(Path(self.tmp.name) / "r.json"); self.s.load()
        d = date.today()
        for i, rating in enumerate([1, 2, 2, 5, 4]):
            self.s.add(raw(date=(d - timedelta(days=i)).isoformat(), location="Cafe", category="Cafeteria",
                           rating=rating, issue_type="Spill" if rating <= 2 else "None"))
        self.s.add(raw(location="Library", category="Library", rating=5))

    def tearDown(self):
        self.tmp.cleanup()

    def test_summary(self):
        sm = analytics.summarize(self.s.reports)
        self.assertEqual(sm["total"], 6)
        self.assertEqual(sm["avg_rating"], 3.17)
        self.assertEqual(sm["status_counts"]["Critical"], 3)

    def test_recurring(self):
        rec = analytics.recurring_areas(self.s.reports)
        self.assertEqual([r["location"] for r in rec], ["Cafe"])
        self.assertEqual(rec[0]["low_reports"], 3)
        self.assertEqual(rec[0]["top_issue"], "Spill")

    def test_warnings_hotspot(self):
        self.assertTrue(any(w.startswith("HOTSPOT") for w in analytics.warnings(self.s.reports)))

    def test_filter(self):
        self.assertEqual(len(analytics.filter_reports(self.s.reports, keyword="library")), 1)
        self.assertEqual(len(analytics.filter_reports(self.s.reports, max_rating=2)), 3)
        self.assertEqual(len(analytics.filter_reports(self.s.reports, category="Cafeteria", min_rating=4)), 2)

    def test_empty(self):
        self.assertEqual(analytics.summarize([]), {"total": 0})
        self.assertEqual(analytics.warnings([]), [])

    def test_exports(self):
        out = Path(self.tmp.name) / "out"
        paths = export.export_all(self.s.reports, out)
        self.assertEqual(len(paths), 4)
        self.assertTrue(all(p.exists() and p.stat().st_size > 0 for p in paths))


class ImporterTests(unittest.TestCase):
    def test_messy_file_logs_errors(self):
        with tempfile.TemporaryDirectory() as d:
            s = Storage(Path(d) / "r.json"); s.load()
            res = import_csv(ROOT / "data" / "legacy_import_with_errors.csv", s, Path(d) / "logs")
            self.assertEqual(res.imported, 2)           # 1 good row + 1 valid row (its twin is a duplicate)
            self.assertEqual(res.skipped_duplicate, 1)
            self.assertEqual(res.skipped_invalid, 6)
            self.assertTrue(res.log_path and res.log_path.exists())

    def test_missing_file_and_columns(self):
        with tempfile.TemporaryDirectory() as d:
            s = Storage(Path(d) / "r.json"); s.load()
            self.assertIn("Cannot open", import_csv(Path(d) / "nope.csv", s, d).fatal)
            bad = Path(d) / "bad.csv"; bad.write_text("a,b\n1,2\n")
            self.assertIn("missing required", import_csv(bad, s, d).fatal)

    def test_sample_dataset_fully_valid(self):
        with tempfile.TemporaryDirectory() as d:
            s = Storage(Path(d) / "r.json"); s.load()
            res = import_csv(ROOT / "data" / "sample_reports.csv", s, d, rebase_to_today=True)
            self.assertEqual((res.imported, res.skipped_invalid), (41, 0))


if __name__ == "__main__":
    unittest.main()
